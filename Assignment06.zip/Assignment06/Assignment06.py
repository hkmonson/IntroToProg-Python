#-------------------------------#
# Title: To-Do List (Part 2)    #
# Dev: Hannah Monson            #
# Date: August 20, 2019         #
#-------------------------------#

global master_todo_list
master_todo_list = []    # create empty Master To-Do list to store dictionary elements

class ToDoList(object):
    """ This class contains methods for manipulating the To-Do List """

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python List and Dictionary.
    @staticmethod
    def access_data():

        # import ToDo.txt file
        todo_txt_file = open("ToDo.txt", "r")

        # loop through txt file and split lines into task and priority
        for line in todo_txt_file:
            item = line.split(",")
            task, priority = item
            priority = priority.strip()  # remove newline character after priority

            # set cases
            task = task.title()
            priority = priority.lower()

            # add line from txt file as row in dictionary
            row = {'task': task,
                   'priority': priority
                   }

            # add dictionary as entry in master list
            master_todo_list.append(row)

        todo_txt_file.close()

# Step 2
# Display a menu of choices to the user
    @staticmethod
    def menu():
        """Offer user menu of options"""
        choice = 0
        while choice != 5:
            print("""
  ****** Main Menu ******
  1 - Show current data
  2 - Add a new task
  3 - Remove a task
  4 - Save data to file
  5 - Exit
  ***********************
            """)
            choice = input("Select an option: ")

            if choice == '1':
                ToDoList.display_list()

            elif choice == '2':
                task = input("Enter new task: ").title().strip()
                priority = input("Enter priority (low/high): ").lower().strip()
                ToDoList.add_item(task, priority)
                print("Task added!")

            elif choice == '3':
                task = input("Enter task to remove: ").title().strip()
                ToDoList.remove_item(task)
                print("Task removed!")

            elif choice == '4':
                ToDoList.save_data()
                print("Data saved!")

            elif choice == '5':
                ToDoList.save_data()
                print("Go git 'er done!")
                break

            else:
                print("\nI'm sorry, but", choice, "is not a valid choice.")
                print("Please enter a number 1-5.")


# Step 3
# Display all todo items to user
    @staticmethod
    def display_list():
        """Display current To-Do List to user"""
        print("\nYour list currently includes:")
        print("  TASK---PRIORITY")
        for row in master_todo_list:
            print("  " + row["task"] + "---" + row["priority"])
        input("\nPress 'Enter' to return to the main menu.")

# Step 4
# Add a new item to the list/Table
    @staticmethod
    def add_item(task, priority):
        row = {
            'task': task,
            'priority': priority
        }
        master_todo_list.append(row)

# Step 5
# Remove an item from the list/Table
    @staticmethod
    def remove_item(task):
        for row in master_todo_list:
            if task in row['task']:
                master_todo_list.remove(row)

# Step 6
# Save tasks to the ToDo.txt file
    @staticmethod
    def save_data():
        """Save current To-Do list in ToDo.txt"""
        todo_txt_file = open("ToDo.txt", "w")
        for row in master_todo_list:
            strTask = str(row['task'])
            strPriority = str(row['priority'])
            todo_txt_file.write(strTask + "," + strPriority)
            todo_txt_file.write("\n")
        todo_txt_file.close()

#-- Input/Output --#
# Welcome user
print("Welcome to your To-Do List!")

# Load data
ToDoList.access_data()

# User can see a Menu
ToDoList.menu()

# From menu, user can see data (1), add tasks (2), remove tasks (3), and save to file (4)