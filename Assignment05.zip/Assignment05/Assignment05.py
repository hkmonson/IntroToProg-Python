#-------------------------------#
# Title: To-Do List             #
# Dev: Hannah Monson            #
# Date: August 13, 2019         #
#-------------------------------#

# - - Data - - #

# create empty Master To-Do list to store dictionary elements
master_todo_list = []

# import ToDo.txt file
todo_txt_file = open("ToDo.txt", "r")

# loop through txt file and split lines into task and priority
for line in todo_txt_file:
    item = line.split(",")
    task, priority = item

    # set cases
    task = task.title()
    priority = priority.lower()

    # remove newline character after priority
    priority = priority[:-1]

    # add line from txt file as row in dictionary
    row = {'task': task,
           'priority': priority
        }

    # add dictionary as entry in master list
    master_todo_list.append(row)

todo_txt_file.close()

# - - Processing - - #

def display_list():
    """Display current To-Do List to user"""
    print("\nYour list currently includes:")
    print("  TASK---PRIORITY")
    for row in master_todo_list:
        print("  " + row["task"] + "---" + row["priority"])

def save_data():
    """Save current To-Do list in ToDo.txt"""
    todo_txt_file = open("ToDo.txt", "w")
    for row in master_todo_list:
        strTask = str(row['task'])
        strPriority = str(row['priority'])
        todo_txt_file.write(strTask + "," + strPriority)
        todo_txt_file.write("\n")
    todo_txt_file.close()
    print("Data saved!")

def menu():
    """Offer user menu of options"""
    choice = 0
    while choice != 5:
        print("""
  ****** Main Menu ******
  1 - Show current data
  2 - Add a new task
  3 - Remove a task
  4 - Save data to file
  5 - Exit
  ***********************
        """)
        choice = input("Select an option: ")

        if choice == '1':
            display_list()
            input("Press 'Enter' to return to the main menu.")

        elif choice == '2':
            task = input("Enter new task: ").title()
            priority = input("Enter priority (low/high): ").lower()
            row = {
                'task': task,
                'priority': priority
            }
            master_todo_list.append(row)

        elif choice == '3':
            task = input("Enter task to remove: ").title()
            for row in master_todo_list:
                if task in row['task']:
                    master_todo_list.remove(row)
            print("Task removed!")

        elif choice == '4':
            save_data()

        elif choice == '5':
            break

        else:
            print("\nI'm sorry, but", choice, "is not a valid choice.")
            print("Please enter a number 1-5.")

# - - Presentation (I/O) - - #

# welcome user
print("*** Welcome to your To-Do List! ***")

# display initial list to user
display_list()

# offer user menu of options
menu()

# save data to .txt file when program ends
save_data()
