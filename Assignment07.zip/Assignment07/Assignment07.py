#----------------------------------------------#
# Title: Pickling and Exception Handling       #
# Dev: Hannah Monson                           #
# Date: August 24, 2019                        #
#----------------------------------------------#

# - - Data - - #

import pickle
import random

# - - Processing - - #

def affirmations():
    '''Make a list of responses affirming user's custom happy things.'''
    num = random.randint(1, 4)
    if num == 1:
        print("That makes me happy too!")
    elif num == 2:
        print("Great choice!")
    elif num == 3:
        print("So many warm fuzzies!")
    elif num == 4:
        print("I'm smiling just thinking about it!")
    else:
        print("Hm. Something went wrong.")

def save_to_file(your_list):
    '''Opens file and saves list as binary'''
    # The first time program is run, the file happy_things.dat is created
    # After that, this function opens file called happy_things.dat

    file = open("happy_things.dat", "wb")
    pickle.dump(your_list, file) # Save list in file
    file.close() # Close file

def add_to_file(your_list):
    '''Add user's happy things to file'''
    file = open("happy_things.dat", "a+b")  # Open file in append mode
    pickle.dump(your_list, file)  # Add user's list to existing list in file
    file.close()  # Close file

def read_file():
    '''Opens file and reads contents'''
    try:
        file = open("happy_things.dat", "rb")
        first_list = pickle.load(file)
        print("\nHere's a list of happy things:")
        for item in first_list: print(" - " + item)
        try:
            second_list = pickle.load(file)
            for item in second_list: print(" - " + item)
        except EOFError: pass
        file.close()  # Close file
    except:  # in case file doesn't exist
        print("\nUnable to load file.")

# - - Input/Output - - #

# Create list of items to store
happy_things = ["Puppies", "Sunshine", "Laughter", "Ice Cream"]

save_to_file(happy_things)
read_file()

# Allow user to add happy things to list
custom_happy_things = []
while True:
    try:
        new_item = input("\nName a happy thing (or type 'exit' to quit): ").strip().title()
        if new_item == 'Exit': break
        else:
            custom_happy_things.append(new_item)
            affirmations()
    except Exception:
        print("Oh no! Something isn't working quite right!")

add_to_file(custom_happy_things)
read_file()